PennController.ResetPrefix(null)

newTrial(
    newButton("Hello World")
        .print()
        .wait()
)
