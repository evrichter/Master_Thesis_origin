PennController.ResetPrefix()

newTrial(
    newButton("Hello world")
        .print()
        .wait()
)